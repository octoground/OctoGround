<?php

namespace app\models;

use Yii;
// use app\models\Table;

use yii\helpers\ArrayHelper;
use app\modules\edit\models\Table;
use app\modules\edit\models\DynamicModel;

class Linked extends \yii\db\ActiveRecord
{
    /**
     * @inheritdoc
     */
    public static function tableName()
    {
        return 'linked';
    }

    /**
     * @inheritdoc
     */
    public function rules()
    {
        return [
            [['type_view'], 'integer'],
            [['parent_table', 'name_linked_table', 'name_linked_table_field', 'checkbox_table'], 'safe'],
            [['linked_name', 'header_linked_table', 'type_view', 'parent_table', 'name_linked_table', 'linked_name'], 'required'],
            [['linked_name', 'header_linked_table'], 'string', 'max' => 255],
        ];
    }

    /**
     * @inheritdoc
     */
    public function attributeLabels()
    {
        return [
            'id' => 'ID',
            'linked_name' => 'Название связи',
            'parent_table' => 'Родительская таблица',
            'name_linked_table' => 'Название связной таблицы',
            'header_linked_table' => 'Заголовок связной таблицы',
            'type_view' => 'Тип отображения',
            'name_linked_table_field' => 'Поле для храненея ключа',
            'checkbox_table' => 'Таблица хранения checkbox',
        ];
    }
    /*
    * Выбираем связную таблицу
    */
    public function getTables()
    {
        $arr = [];
        $items = \Yii::$app->dbFrontEnd->getSchema()->tableNames;

        foreach ($items as $key => $item) {
            $arr[$item] = $item;
        }
        return $arr;
    }
    public function getTable(){
        return Table::find()->where(['name' => $this->name_linked_table])->one();
    }
    public function getInsert($model, $lastInsert){

        if (   $model->table->name === 'product' ) {
            $sub = $model->table->linked->table;
            $id_parent = $model->table->linked->name_linked_table_field;   
        }else{
            $sub = $model->table->linkedPages->table;
            $id_parent = $model->table->linkedPages->name_linked_table_field;   
        }
            
        $table = Table::find()->where(['name' => $sub->name])->one();
        $fields = Field::find()->where(['table_id' => $table->id, 'is_editable' => true])->asArray()->all();
        $fields = ArrayHelper::map($fields, 'name', 'name');

        // var_dump(\Yii::$app->request->post());
        $arr = array_intersect_key(\Yii::$app->request->post()["DynamicModel"], $fields);
        $arr_key = array_keys($arr);

        if($arr[$arr_key[0]]){
            $res = $arr[$arr_key[0]];
        }else{
            $res = $arr;
        }
        
        $arr_count = count($res);
        for($i = 0; $i < $arr_count; $i++){     
            $sub = new DynamicModel([], ['table' => $table]);  

            for($j = 0; $j < count($arr); $j++){

                $k = array_keys($arr[$arr_key[$j]]);
                $sub[$arr_key[$j]] = $arr[$arr_key[$j]][$k[$i]];
                
            }
            
            $sub[$id_parent] = $lastInsert;

            // var_dump($sub->insert());
            if(!$sub->insert()){
                var_dump('errro'); 
                die;
            }
           
        }
        return true;
    }

    public function getUpdate($id, $table)
    {
        if (!$this->validate()) {
            return false;
        }
        //записываем в базу данные с формы
        return $this->getProcessedDataForPHP(\Yii::$app->dbFrontEnd->createCommand("SELECT * FROM {$table} WHERE {$field}={$id}")->queryAll());
        // return \Yii::$app->dbFrontEnd->createCommand()->update($table, $this->getProcessedDataForDB(), ['id' => $id])->execute();

    }

    public function parentColumnName($id){
        $table = Table::findOne($id);        
        return $table->linked->name_linked_table_field;
    }
}
