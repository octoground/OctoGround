<?php

namespace app\modules\edit\models;

use yii\db\ActiveRecord;
use app\models\Linked;
use app\modules\edit\models\Field;
/**
 * @inheritdoc
 */
class Table extends \app\models\Table
{

    /**
     * @return array|ActiveRecord[]
     */
    public function getGalleries()
    {
        return Gallery::find()->where(['destination_table_name' => $this->name])->all();
    }

    public function getLinked()
    {
        return Linked::find()->where(['parent_table' => $this->name])->one();
    }
    public function getLinkedcheckbox()
    {
        return Linked::find()->where(['parent_table' => $this->name, 'type_view' => '4'])->one();
    }
    public function getLinkedPages()
    {
        return Linked::find()->where(['parent_table' => $this->name, 'type_view' => '1'])->one();
    }
    public function getField()
    {
        $table_id = $this->linked->table->id;
        $fields = Field::find()
        ->where(['table_id' => $table_id, 'is_editable' => true])
        ->all();
        return $fields;
    }
    public function getGalleryTitle($num){
        $words = ['Галерея', 'Галереи', 'Галереи'];
        $num = $num % 100;
        if ($num > 19) {
            $num = $num % 10;
        }
        switch ($num) {
            case 1: {
                return($words[0]);
            }
            case 2: case 3: case 4: {
                return($words[1]);
            }
            default: {
                return($words[2]);
            }
        }
    }
}
