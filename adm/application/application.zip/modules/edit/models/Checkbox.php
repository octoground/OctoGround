<?php

namespace app\modules\edit\models;

class Checkbox extends \app\models\Table
{
    public $t_name; //Наименнование таблицы
    public $checkbox_table; // Таблица, в которой хранятся значения checkbox
    public $checkbox;


    public function getTable($q = null)
    {
        $q = $this->t_name === 'accessory' ? 'title' : 'name'; 
        return \Yii::$app->dbFrontEnd->createCommand("SELECT id, {$q} FROM {$this->t_name}")->queryAll();
    }

    public function getArray($q = null)
    {
        $items = $this->getTable($q);
        $arr = [];

        foreach ($items as $key => $item) {
            $arr[$item['id']] = isset($item['name']) ? $item['name'] : $item['title'];
        }
        return $arr;
    }

    public function getSelected($id)
    {
        $arr = [];
        $items = \Yii::$app->dbFrontEnd->createCommand("SELECT table1 FROM {$this->checkbox_table} WHERE table2 = " . $id)->queryAll();

        foreach ($items as $key => $item) {
            $arr[] = $item['table1'];
        }

        return $arr;
    }
}
