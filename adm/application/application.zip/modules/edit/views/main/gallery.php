<?php
    use yii\helpers\Url;
    if($table->getGalleries()){

        $c_galery = count($table->getGalleries());
        echo "<div class='linked_header'><h1>". $table->getGalleryTitle($c_galery) ."</h1></div>";

        foreach($table->getGalleries() as $key => $galleries){
            $galleries->loadImages($row_id);      
            $rand = rand();
            echo "<div class='row edit_row gallery_edit_row'>";
                echo "<div class='col-lg-12'>";
                    echo "<div class='gallery_linked_content'>";                       
                        echo "<label>" . $galleries->name . "</label>";
                        
                        echo "<div class='gallery_linked_label'>";

                            foreach ($galleries->images as $image){
                                if($image){
                                    echo $this->render('templates/gallery', compact('image', 'galleries', 'row_id'));   
                                }
                            }                     

                            echo "<label for='image-uploader". $rand ."' class='pre_gallery'>";
                                echo "<input type='file' accept='image/*' multiple='multiple' name='file' id='image-uploader". $rand ."' data-table='gallery_{$galleries->destination_table_name}_{$galleries->id}_{$row_id}'' class='hide gallery-uploader' data-upload-url='" . Url::to(['/tools/upload-image']) . "'>";
                                echo '<div class="edit_image_load">';
                                    echo '<div class="edit_image_load_field">';

                                        echo "<i class='fa fa-plus-circle' aria-hidden='true'></i>"; 
                                
                                    echo '</div>';
                                echo '</div>';
                            echo "</label>";
                        echo "</div>"; 
                    echo "</div>"; 
                echo "</div>"; 
            echo "</div>"; 
        }
        
    }

?>