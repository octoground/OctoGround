<?php

namespace app\modules\edit\controllers;

use yii;
use yii\helpers\Url;
use app\components\Controller;
use app\models\ImageCropperSettings;
use app\models\Linked;
use app\modules\edit\models\Field;
use app\modules\edit\models\Table;
use app\modules\edit\models\DynamicModel;
use app\modules\edit\models\Gallery;
use lavrentiev\widgets\toastr\Notification;
use yii\helpers\ArrayHelper;

class MainController extends Controller
{
    public function actionIndex($id)
    {
        /** @var Table $table */
        $table = Table::findOne($id);
        $searchModel = new DynamicModel([], ['table' => $table]);
        $provider = $searchModel->search(\Yii::$app->request->queryParams);

        $list = \Yii::$app->dbFrontEnd->createCommand("SELECT * FROM {$table->name}")
            ->bindValues([
                ':id' => $id
            ])->queryAll();

        return $this->render('index', [
            'provider' => $provider,
            'table' => $table,
            'searchModel' => $searchModel,
            'list' => $list,
        ]);
    }

    public function actionEdit($id, $table, $row_id = false, $parent_table = false, $parent_row = false, $is_row = false)
    {
        // var_dump(\Yii::$app->request->queryParams);
        /** @var Table $tableModel */
        $tableModel = Table::findOne($table);
        /** @var Field[] $fields */

        $fields = Field::find()
            ->where(['table_id' => $tableModel->id, 'is_editable' => true, 'name' => \Yii::$app->dbFrontEnd->getTableSchema($tableModel->name)->columnNames])
            ->all();

        $settingsCropper = ImageCropperSettings::find()->all();

        $arraySettingsCropper = [];
        foreach ($settingsCropper as $item) {
            $arraySettingsCropper[$item->title_column] = $item;
        }
        //Создаем динамическую модель для валидаии данных
        $model = new DynamicModel([], ['table' => $tableModel]);
        $model->loadFromDB($id);

        if ($model->load(\Yii::$app->request->post())) {
            if ($is_row) {
                $link = new Linked();
                $name = $link->parentColumnName($parent_table);
                if ($name) {
                    $i = $parent_row ? $parent_row : $row_id;
                    $model[$name] = $i;
                }
            }
            // echo "<pre>";

            // var_dump(\Yii::$app->request->post());
            // echo "</pre>";
            $this::modelSave($model, $id, \Yii::$app->request->post(), $tableModel);

            if (isset(Yii::$app->request->post()["Checkbox"]["checkbox"])) { //Множественный выбор (checkbox)

                $t_name_checkbox = $model->table->linked->checkbox_table ? $model->table->linked->checkbox_table : $model->table->linkedcheckbox->checkbox_table;
                $checkbox = Yii::$app->request->post()["Checkbox"]["checkbox"];
                // var_dump($model->table->linkedcheckbox->checkbox_table);die;
                Yii::$app->dbFrontEnd->createCommand()->delete($t_name_checkbox, 'table2 = ' . $id)->execute();
                foreach ($checkbox as $key => $item) {
                    Yii::$app->dbFrontEnd->createCommand()->insert($t_name_checkbox, [
                        'table1' => $item,
                        'table2' => $id,
                    ])->execute();
                }
            }

            foreach (Yii::$app->request->post() as $key => $data) {
                $expl = explode("_", $key);
                $expl_name = $expl[0];
                $expl_id_gallery = $expl[2];
                // $expl_id = Yii::$app->dbFrontEnd->getLastInsertID();
                $expl_id = $expl[3];

                if ($expl_name === 'gallery') {
                    $this::uploadGallery($expl_id, $expl_id_gallery, $data);
                }
            }

            if (Yii::$app->request->isAjax) {
                die;
            } else {
                if ($is_row) {
                    return $this->redirect(['/edit/main/edit', 'id' => $row_id, 'table' => $parent_table]);
                }

                return $this->goBack();
            }
        }


        $session = Yii::$app->session;
        // if(strpos(Yii::$app->request->referrer, 'adm/edit/main/edit/') && $session->has('_index')){
        //     // Yii::$app->request->referrer = null;
        $session->set('_index', 'true');
        //     $session->remove('_index', 'true');

        //     var_dump($session->get('_index'));
        // }


        return $this->render('edit', [
            'fields' => $fields,
            'model' => $model,
            'table' => $tableModel,
            'settingsCropper' => $arraySettingsCropper,
            'row_id' => $id,
            'is_row' => $is_row,
            'parent_table' => $parent_table,
            'parent_row' => $row_id
        ]);
    }

    static function modelSave($model, $id, $table = null, $tableModel)
    {
        // $ar = \Yii::$app->request->post()["DynamicModel"];
        // foreach ($ar as $key => $value) {
        //     if (is_array($value)) {
        //         unset($ar[$key]);
        //         // var_dump($key);
        //     }
            
        //     // var_dump($key);
        //     // var_dump(\Yii::$app->request->post());
        // }
        // var_dump(\Yii::$app->request->post());
        // $e = new DynamicModel([], ['table' => $tableModel]);
        // $e->loadFromDB($id);
        // $e->load($ar);
        if (!$model->update($id)) {

            // var_dump($e->errors);
            // var_dump($e);

            if ($model->table->linked->type_view == '1' || $model->table->linkedPages->type_view) {
                $tableM = Table::find()->where(['name' => $model->table->linkedPages->name_linked_table])->one();
                $sub = new DynamicModel([], ['table' => $tableM]);

                $sub->delete($id, $model->table->linkedPages->name_linked_table, $model->table->linkedPages->name_linked_table_field);
                $model->table->linkedPages->getInsert($model, $id, $table);
            }
            return true;
        }
    }

    public function actionChangeSort()
    {
        $table = \Yii::$app->request->post('table');
        $id = \Yii::$app->request->post('id');
        $value_sort = \Yii::$app->request->post('value_sort');
        /** @var Table $tableModel */
        $tableModel = Table::findOne($table);
        /** @var Field[] $fields */
        $fields = Field::find()->where(['table_id' => $tableModel->id, 'is_editable' => true, 'name' => \Yii::$app->dbFrontEnd->getTableSchema($tableModel->name)->columnNames])->all();
        //СОздаем динамическую модель для валидаии данных
        $model = new DynamicModel([], ['table' => $tableModel]);
        $model->loadFromDB($id);
        $model->sort = $value_sort;
        if ($model->update($id) !== false) {
            \Yii::$app->session->setFlash('success', 'Запись успешно отредактирована');
            return $this->goBack();
        }
    }
    public function actionDelete($id, $table)
    {
        /** @var Table $tableModel */
        $tableModel = Table::findOne($table);
        //СОздаем динамическую модель для валидаии данных
        $model = new DynamicModel([], ['table' => $tableModel]);
        if ($model->delete($id) === false) {
            $type = 'danger';
            $message = 'Не удалось удалить запись';
        } else {
            $type = 'success';
            $message = 'Запись успешно удалена';
        }

        Notification::widget([
            'type' => $type,
            'message' => $message
        ]);

        return $this->renderPartial('templates/empty_table');
    }

    public function actionCreate($id = null, $table, $is_row = false, $parent_row_id = false, $parent_row = false, $parent_table_id = false, $parent_table = false)
    {
        /** @var Table $tableModel */
        $tableModel = Table::findOne($table);
        /** @var Field[] $fields */
        $fields = Field::find()->where(['table_id' => $tableModel->id, 'is_editable' => true, 'name' => \Yii::$app->dbFrontEnd->getTableSchema($tableModel->name)->columnNames])->all();
        $settingsCropper = ImageCropperSettings::find()->all();
        $arraySettingsCropper = [];
        foreach ($settingsCropper as $item) {
            $arraySettingsCropper[$item->title_column] = $item;
        }
        $model = new DynamicModel([], ['table' => $tableModel]);


        if (Yii::$app->request->isAjax && $id !== "null") {
            $model->loadFromDB($id);
        }

        // if($is_row){
        //     $m = Table::findOne($parent_table_id);
        // var_dump('dasdasdas');
        // }
        // die;
        if ($model->load(\Yii::$app->request->post())) {
            // var_dump($parent_row_id);
            // var_dump($parent_row);
            // var_dump($parent_table_id);
            // var_dump($parent_table);
            // if($parent_row_id){
            //     $id = $parent_row_id;
            //     $lastID = $parent_row_id;

            // }   


            $parent_table = $parent_table ? $parent_table : $parent_table_id;
            if ($is_row) {
                $link = new Linked();
                $name = $link->parentColumnName($parent_table);
                if ($name) {
                    // $i = $parent_row_id ? $parent_row_id : $id;
                    $i = $parent_row_id ? $parent_row_id : $parent_row;
                    // var_dump($i);
                    // die;
                    $model[$name] = $i;
                }
                // var_dump($link);
                // die;
            }
            // var_dump($parent_table . ' - sasasda');
            // var_dump($id . ' - id');  die;
            // var_dump($parent_row_id . ' - row');  
            if ($id !== null && $id !== 'null') { #AJAX сохранение в бд
                if (Yii::$app->request->isAjax) {

                    $this::modelSave($model, $id, $parent_table);
                    $lastID11 = Yii::$app->dbFrontEnd->getLastInsertID();


                    // if (isset(Yii::$app->request->post()["Checkbox"]["checkbox"])) {

                    //     $checkbox = Yii::$app->request->post()["Checkbox"]["checkbox"];
                    //     // var_dump($lastID11);
                    // }
                    // die;

                    foreach (Yii::$app->request->post() as $key => $data) {
                        $expl = explode("_", $key);
                        $expl_name = $expl[0];
                        $expl_id_gallery = $expl[2];
                        $expl_id = $lastID11;

                        if ($expl_name === 'gallery') {

                            $this::uploadGallery($expl_id, $expl_id_gallery, $data);
                        }
                    }
                    return json_encode(['id' => $id]);
                }
            } else {
                if ($model->insert()) { #вставка новой строки в бд

                    $lastID = Yii::$app->dbFrontEnd->getLastInsertID();

                    foreach (Yii::$app->request->post() as $key => $data) {
                        $expl = explode("_", $key);
                        $expl_name = $expl[0];
                        $expl_id_gallery = $expl[2];
                        $expl_id = $lastID;
                        // $expl_id = $expl[3];

                        if ($expl_name === 'gallery') {

                            $this::uploadGallery($expl_id, $expl_id_gallery, $data);
                        }
                    }

                    if ($model->table->linked->type_view == '1') {
                        $model->table->linked->getInsert($model, $lastID, $parent_table, true);

                        if (Yii::$app->request->isAjax) {
                            return json_encode(['id' => $lastID]);
                        }
                    }
                    if ($is_row) {
                        return $this->redirect(['/edit/main/edit', 'id' => $parent_row_id, 'table' => $parent_table_id]);
                    }
                    return $this->goBack();
                }
            }
        }

        return $this->render('create', [
            'fields' => $fields,
            'model' => $model,
            'tableModel' => $tableModel,
            'settingsCropper' => $arraySettingsCropper,
            'table' => $table,
            'is_row' => $is_row
        ]);
    }
    public function actionDouble($id = null, $table)
    {
        /** @var Table $tableModel */
        $tableModel = Table::findOne($table);
        /** @var Field[] $fields */
        $fields = Field::find()->where(['table_id' => $tableModel->id, 'is_editable' => true, 'name' => \Yii::$app->dbFrontEnd->getTableSchema($tableModel->name)->columnNames])->all();

        $settingsCropper = ImageCropperSettings::find()->all();
        $arraySettingsCropper = [];
        foreach ($settingsCropper as $item) {
            $arraySettingsCropper[$item->title_column] = $item;
        }
        $model = new DynamicModel([], ['table' => $tableModel]);

        if ($model->load(\Yii::$app->request->post())) {

            if (Yii::$app->request->isAjax && $id !== 'null') {
                $model->id = $id;
                $this::modelSave($model, $id);
                return json_encode(['id' => $id]);
            } else {
                if ($model->insert()) { #вставка новой строки в бд                    
                    $lastID = Yii::$app->dbFrontEnd->getLastInsertID();

                    if ($model->table->linked->type_view == '1') {
                        $model->table->linked->getInsert($model, $lastID, \Yii::$app->request->post()["DynamicModel"]);

                        if (Yii::$app->request->isAjax) {
                            return json_encode(['id' => $lastID]);
                        }
                    }


                    return $this->goBack();
                }
            }
        }

        if (!Yii::$app->request->isAjax) {
            $model->loadFromDB($id);
        }
        return $this->render('create', [
            'fields' => $fields,
            'model' => $model,
            'table' => $tableModel->id,
            'tableModel' => $tableModel,
            'settingsCropper' => $arraySettingsCropper
        ]);
    }
    public function actionCropImage()
    {
        return $this->renderAjax('/templates/modal');
    }

    static function uploadGallery($id, $gallery, $data)
    {
        $galleryModel = Gallery::findOne($gallery);
        $galleryModel->loadImages($id);
        $galleryModel->saveImages($data, $id);
    }
}
