<?php

namespace app\modules\edit\controllers;

use yii;
use app\components\Controller;
use app\modules\edit\models\DynamicModel;
use yii\bootstrap\ActiveForm;
use app\modules\edit\models\Table;
use app\modules\edit\models\Field;
use app\models\ImageCropperSettings;

class ToolsController extends Controller
{
    
    public function actions()
    {   
        $this->enableCsrfValidation = false;
        return [
            'images-get' => [
                'class' => 'vova07\imperavi\actions\GetImagesAction',
                'url' => Yii::$app->request->hostInfo . '/images/improve', // Directory URL address, where files are stored.
                'path' => Yii::getAlias('@app') . '/../../images/improve', // Or absolute path to directory where files are stored.
                'options' => ['only' => ['*.jpg', '*.jpeg', '*.png', '*.gif', '*.ico']], // These options are by default.
            ],
            'file-delete' => [
                'class' => 'vova07\imperavi\actions\DeleteFileAction',
                'url' => Yii::$app->request->hostInfo . '/images/improve', // Directory URL address, where files are stored.
                'path' => Yii::getAlias('@app') . '/../../images/improve', // Or absolute path to directory where files are stored.
            ],
            'files-get' => [
                'class' => 'vova07\imperavi\actions\GetFilesAction',
                'url' => Yii::$app->request->hostInfo . '/images/improve', // Directory URL address, where files are stored.
                'path' => Yii::getAlias('@app') . '/../../images/improve', // Or absolute path to directory where files are stored.
            ],
            'file-upload' => [
                'class' => 'vova07\imperavi\actions\UploadFileAction',
                'url' => Yii::$app->request->hostInfo . '/images/improve', // Directory URL address, where files are stored.
                'path' => Yii::getAlias('@app') . '/../../images/improve', // Or absolute path to directory where files are stored.
                'uploadOnlyImage' => false, // For any kind of files uploading.
            ],         
        ];
    }
    public function actionAddRow($table)
    {
        $form = ActiveForm::begin();
        $table_name = Table::find()->where(['name' => $table])->one();
        $model = new DynamicModel([], ['table' => $table_name]);
        $fields = Field::find()->where(['table_id' => $table_name->id, 'is_editable' => true])->all();
        $row = true;

        $arraySettingsCropper = ImageCropperSettings::find()->all();
        $settingsCropper = [];
        foreach ($arraySettingsCropper as $item) {
            $settingsCropper[$item->title_column] = $item;
        }

        return $this->renderAjax('/main/templates/row', compact('model', 'fields', 'form', 'row', 'table_name', 'settingsCropper'));
    }
}

