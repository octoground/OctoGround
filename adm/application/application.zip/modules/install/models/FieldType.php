<?php

namespace app\modules\install\models;

/**
 * @inheritdoc
 */
class FieldType extends \app\models\FieldType
{

}
