<?php

namespace app\modules\install\models;

/**
 * @inheritdoc
 */
class FieldShowType extends \app\models\FieldShowType
{

}
