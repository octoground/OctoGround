<?php
namespace app\components;

/**
 * Class User
 * @package application\components
 * @property \app\models\User $identity
 */
class User extends \yii\web\User
{

}